"""Blender import / export / texture-prefix remap for OFP SP3X MLOD."""

from __future__ import annotations

import os

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from .lod_types import LOD_BY_ID, kind_from_resolution
from .sp3x import Face, Lod, Model, Sp3xError, Vertex, read_path, write_path


def _yup_to_blender(x, y, z):
    # Oxygen Y-up → Blender Z-up
    return (x, z, y)


def _blender_to_yup(x, y, z):
    return (x, z, y)


def _ensure_collection(name, parent=None):
    if parent is not None:
        existing = parent.children.get(name)
        if existing is not None:
            return existing
        col = bpy.data.collections.new(name)
        parent.children.link(col)
        return col
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col


def _link_object(obj, collection):
    for col in list(obj.users_collection):
        col.objects.unlink(obj)
    collection.objects.link(obj)


def _material_for_path(path):
    path = path.replace("/", "\\")
    if not path:
        path = "no_texture"
    mat = bpy.data.materials.get(path)
    if mat is None:
        mat = bpy.data.materials.new(path)
        mat.use_nodes = False
        mat.diffuse_color = (0.6, 0.6, 0.55, 1.0)
    return mat


def model_to_scene(context, model, model_name, replace_prefix=""):
    scene = context.scene
    scene.o2l.model_name = model_name
    root_name = f"O2L_{model_name}"
    root = _ensure_collection(root_name)
    created = []
    if replace_prefix:
        old, _, new = replace_prefix.partition("=>")
        if old and new:
            model.replace_texture_prefix(old.strip(), new.strip())

    for lod in model.lods:
        kind_id = kind_from_resolution(lod.resolution)
        kind = LOD_BY_ID[kind_id]
        if kind_id == "res":
            name = f"{model_name} {kind.label} {lod.resolution:g}"
        else:
            name = f"{model_name} {kind.label}"
        mesh = bpy.data.meshes.new(name)
        verts = [_yup_to_blender(v.x, v.y, v.z) for v in lod.vertices]
        faces = [tuple(f.verts) for f in lod.faces]
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        tex_order = []
        tex_index = {}
        for face in lod.faces:
            key = face.texture.replace("/", "\\") if face.texture else "no_texture"
            if key not in tex_index:
                tex_index[key] = len(tex_order)
                tex_order.append(key)
                mesh.materials.append(_material_for_path(key))
        if faces:
            for i, face in enumerate(lod.faces):
                key = face.texture.replace("/", "\\") if face.texture else "no_texture"
                if i < len(mesh.polygons):
                    mesh.polygons[i].material_index = tex_index[key]

        if faces and any(f.uvs for f in lod.faces):
            uv = mesh.uv_layers.new(name="UVMap")
            loop = 0
            for fi, face in enumerate(lod.faces):
                for uvxy in face.uvs:
                    if loop < len(uv.data):
                        uv.data[loop].uv = (uvxy[0], 1.0 - uvxy[1])
                    loop += 1

        if lod.masses:
            attr = mesh.attributes.new("o2l_mass", "FLOAT", "POINT")
            for i, mass in enumerate(lod.masses):
                if i < len(mesh.vertices):
                    attr.data[i].value = mass
        attr_f = mesh.attributes.new("o2l_vflag", "INT", "POINT")
        for i, v in enumerate(lod.vertices):
            if i < len(mesh.vertices):
                attr_f.data[i].value = v.flags

        obj = bpy.data.objects.new(name, mesh)
        obj.o2l.is_lod = True
        obj.o2l.lod_kind = kind_id
        obj.o2l.resolution = lod.resolution if kind_id == "res" else kind.resolution
        for key, val in lod.properties:
            item = obj.o2l.properties.add()
            item.name = key
            item.value = val
        for sel_name, (vw, _fw) in lod.selections.items():
            vg = obj.vertex_groups.new(name=sel_name)
            idxs = [i for i, w in enumerate(vw) if w]
            if idxs:
                vg.add(idxs, 1.0, "REPLACE")
        col = _ensure_collection(name, root)
        _link_object(obj, col)
        created.append(obj)

    if created:
        for obj in context.selected_objects:
            obj.select_set(False)
        context.view_layer.objects.active = created[0]
        created[0].select_set(True)
    return created


def scene_to_model(context, selected_only=False):
    scene = context.scene
    if selected_only:
        objs = [o for o in context.selected_objects if o.type == "MESH" and o.o2l.is_lod]
    else:
        root = bpy.data.collections.get(f"O2L_{scene.o2l.model_name or 'model'}")
        if root is not None:
            objs = []

            def walk(col):
                objs.extend(o for o in col.objects if o.type == "MESH" and o.o2l.is_lod)
                for child in col.children:
                    walk(child)

            walk(root)
        else:
            objs = [o for o in scene.objects if o.type == "MESH" and o.o2l.is_lod]
    if not objs:
        raise Sp3xError("No Objektiv2 LOD meshes to export")

    model = Model()
    for obj in objs:
        mesh = obj.data
        kind = LOD_BY_ID.get(obj.o2l.lod_kind)
        res = obj.o2l.resolution if obj.o2l.lod_kind == "res" else (kind.resolution if kind else 0.0)
        lod = Lod(resolution=res)
        mat_world = obj.matrix_world
        for vert in mesh.vertices:
            co = mat_world @ vert.co
            x, y, z = _blender_to_yup(co.x, co.y, co.z)
            flags = 0
            if "o2l_vflag" in mesh.attributes:
                flags = int(mesh.attributes["o2l_vflag"].data[vert.index].value)
            lod.vertices.append(Vertex(x, y, z, flags))
        if "o2l_mass" in mesh.attributes:
            lod.masses = [mesh.attributes["o2l_mass"].data[i].value for i in range(len(mesh.vertices))]
        uv_layer = mesh.uv_layers.active
        lod.normals = [(0.0, 1.0, 0.0)]

        def corner(loop_i):
            vi = mesh.loops[loop_i].vertex_index
            if uv_layer is not None:
                uv = uv_layer.data[loop_i].uv
                return vi, (uv[0], 1.0 - uv[1])
            return vi, (0.0, 0.0)

        for poly in mesh.polygons:
            n = poly.loop_total
            if n < 3:
                continue
            tex = ""
            if poly.material_index < len(mesh.materials) and mesh.materials[poly.material_index]:
                tex = mesh.materials[poly.material_index].name.replace("/", "\\")
            loops = [poly.loop_start + i for i in range(n)]
            fans = [loops[:4]] if n <= 4 else [
                [loops[0], loops[i], loops[i + 1]] for i in range(1, n - 1)
            ]
            for group in fans:
                vis = []
                uvs = []
                for loop_i in group:
                    vi, uv = corner(loop_i)
                    vis.append(vi)
                    uvs.append(uv)
                lod.faces.append(Face(texture=tex, verts=vis, normals=[0] * len(vis), uvs=uvs))
        nverts = len(lod.vertices)
        nfaces = len(lod.faces)
        for vg in obj.vertex_groups:
            vw = [0] * nverts
            for vert in mesh.vertices:
                for g in vert.groups:
                    if g.group == vg.index and g.weight > 0.01:
                        vw[vert.index] = 1
                        break
            fw = [0] * nfaces
            for fi, face in enumerate(lod.faces):
                if face.verts and all(vw[i] for i in face.verts):
                    fw[fi] = 1
            lod.selections[vg.name] = (vw, fw)
        for item in obj.o2l.properties:
            if item.name:
                lod.properties.append((item.name, item.value))
        model.lods.append(lod)
    return model


class O2L_OT_import_p3d(bpy.types.Operator, ImportHelper):
    bl_idname = "o2l.import_p3d"
    bl_label = "Import OFP MLOD (.p3d)"
    bl_description = "Import an unbinarized OFP / Cold War Assault SP3X P3D"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".p3d"
    filter_glob: StringProperty(default="*.p3d", options={"HIDDEN"})
    remap_old: StringProperty(name="Replace prefix", default="")
    remap_new: StringProperty(name="With prefix", default="")

    def execute(self, context):
        try:
            model = read_path(self.filepath)
        except Sp3xError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except OSError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        if self.remap_old:
            new = self.remap_new or self.remap_old
            n = model.replace_texture_prefix(self.remap_old, new)
            self.report({"INFO"}, f"Remapped {n} faces")
        stem = os.path.splitext(os.path.basename(self.filepath))[0]
        created = model_to_scene(context, model, stem)
        self.report({"INFO"}, f"Imported {len(created)} LODs from {stem}.p3d")
        return {"FINISHED"}


class O2L_OT_export_p3d(bpy.types.Operator, ExportHelper):
    bl_idname = "o2l.export_p3d"
    bl_label = "Export OFP MLOD (.p3d)"
    bl_description = "Write an unbinarized OFP / Cold War Assault SP3X P3D"
    bl_options = {"REGISTER"}

    filename_ext = ".p3d"
    filter_glob: StringProperty(default="*.p3d", options={"HIDDEN"})
    selected_only: BoolProperty(name="Selected LODs only", default=False)

    def execute(self, context):
        try:
            model = scene_to_model(context, selected_only=self.selected_only)
            write_path(self.filepath, model)
        except Sp3xError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except OSError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Wrote {len(model.lods)} LODs to {self.filepath}")
        return {"FINISHED"}


class O2L_OT_remap_textures(bpy.types.Operator):
    bl_idname = "o2l.remap_textures"
    bl_label = "Remap texture prefix"
    bl_description = "Replace the start of every OFP texture path on LOD materials"
    bl_options = {"REGISTER", "UNDO"}

    old_prefix: StringProperty(name="Old prefix", default="ILCTI1.01BaseAddon\\")
    new_prefix: StringProperty(name="New prefix", default="mymortar\\")

    def execute(self, context):
        old = self.old_prefix.replace("/", "\\")
        new = self.new_prefix.replace("/", "\\")
        if new and not new.endswith("\\"):
            new += "\\"
        n_mat = 0
        n_obj = 0
        for obj in context.scene.objects:
            if obj.type != "MESH" or not obj.o2l.is_lod:
                continue
            touched = False
            for slot in obj.material_slots:
                mat = slot.material
                if mat is None:
                    continue
                name = mat.name.replace("/", "\\")
                if name.startswith(old):
                    mat.name = new + name[len(old) :]
                    n_mat += 1
                    touched = True
            if touched:
                n_obj += 1
        self.report({"INFO"}, f"Renamed {n_mat} materials on {n_obj} LOD(s)")
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_remap_p3d_file(bpy.types.Operator, ImportHelper):
    bl_idname = "o2l.remap_p3d_file"
    bl_label = "Remap textures in .p3d on disk"
    bl_description = "Rewrite face texture prefixes in an SP3X file without importing the mesh"
    bl_options = {"REGISTER"}

    filename_ext = ".p3d"
    filter_glob: StringProperty(default="*.p3d", options={"HIDDEN"})
    old_prefix: StringProperty(name="Old prefix", default="ILCTI1.01BaseAddon\\")
    new_prefix: StringProperty(name="New prefix", default="mymortar\\")

    def execute(self, context):
        old = self.old_prefix.replace("/", "\\")
        new = self.new_prefix.replace("/", "\\")
        if new and not new.endswith("\\"):
            new += "\\"
        try:
            model = read_path(self.filepath)
            n = model.replace_texture_prefix(old, new)
            write_path(self.filepath, model)
        except Sp3xError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Rewrote {n} faces in {os.path.basename(self.filepath)}")
        return {"FINISHED"}


CLASSES = (
    O2L_OT_import_p3d,
    O2L_OT_export_p3d,
    O2L_OT_remap_textures,
    O2L_OT_remap_p3d_file,
)


def _menu_import(self, context):
    self.layout.operator(O2L_OT_import_p3d.bl_idname, text="OFP MLOD (.p3d)")


def _menu_export(self, context):
    self.layout.operator(O2L_OT_export_p3d.bl_idname, text="OFP MLOD (.p3d)")


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)
    bpy.types.TOPBAR_MT_file_export.append(_menu_export)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    bpy.types.TOPBAR_MT_file_export.remove(_menu_export)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
