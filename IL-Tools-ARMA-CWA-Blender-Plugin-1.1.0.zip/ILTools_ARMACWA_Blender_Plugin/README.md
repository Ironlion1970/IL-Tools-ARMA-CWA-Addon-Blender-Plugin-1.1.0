# ILTools ARMA CWA Blender Plugin

A Blender 3.6 / 4.x add-on that recreates the **Objektiv2 Light** modelling workflow on Linux (and anywhere Blender runs).

It reads and writes **OFP / Cold War Assault SP3X MLOD** `.p3d` files. It does **not** read ODOL (binarized) or Arma 3 `P3DM`. For those use odol2mlod or [Arma 3 Object Builder](https://github.com/MrClock8163/Arma3ObjectBuilder).

The sidebar still covers Objektiv2 habits: LODs, named selections, memory points, ComponentXX, named properties, texture-path remap.

## Install

1. Zip the `ILTools_ARMACWA_Blender_Plugin` folder (the folder that contains `__init__.py`).
2. Blender → *Edit → Preferences → Add-ons → Install from Disk*.
3. Disable any old **Objektiv2 Workflow** add-on first.
4. Enable **ILTools ARMA CWA Blender Plugin**.
5. Open the 3D View sidebar (`N`) → tab **Objektiv2**.

Blender 4.2+ also accepts the folder as a legacy add-on.

## Typical OFP object

1. Set **Model** name.
2. **Create Objektiv2 model** — builds Resolution + Geometry + Memory + Land Contact + Hit-points, optionally View / Shadow / Fire+View Geometry.
3. Model the visible mesh in `{model} Resolution 0`.
4. Duplicate / decimate into higher-resolution LOD objects (`{model} Resolution 1`, `2`, …).
5. Build a crude closed convex collision mesh in **Geometry**. Select each convex piece in Edit Mode → **ComponentXX**.
6. Put the 3D cursor where a muzzle / light / get-in point belongs, select the Memory mesh, **Add memory point**.
7. Name materials like `data\hummer_co.paa` via **Stamp OFP texture path**.
8. **Validate Objektiv2 model** — scoped to `O2L_<model>`; full log is the `Objektiv2 Report` text block.

## Mapping from Objektiv2 Light

| Objektiv2 Light | This add-on |
|---|---|
| LOD list | Collection per LOD + `is_lod` on the mesh |
| Named selections | Vertex groups |
| Memory points | Loose vertices + a vertex group each |
| Component01–99 | Vertex groups, auto-numbered |
| Named properties (`#Property#`) | Per-LOD key/value list |
| Texture path on a face | Material name (`data\foo.paa`) |
| Pal2Pac / gifload / jpgload | External: ImageToPAA, Pal2PacE, [paa-cli](https://github.com/AdamKearn/paa-cli) |
| KEYLIB32 Light licence gates | Gone |
| PoseidonMessage / IFC22 | Not needed in Blender |

## What it will not do

- Read ODOL (binarized) or Arma 3 `P3DM`.
- Convert PAC/PAA (use ImageToPAA, Pal2PacE, or paa-cli).
- Binarize or pack `.pbo`.
- Enforce SoftwareKey trials.

## 1.1.0

- File → Import / Export → **OFP MLOD (.p3d)** (SP3X only).
- Remap texture prefix on scene materials or on a `.p3d` on disk (the mortar `ILCTI1.01BaseAddon\` fix).

## 1.0.1

- Correct functional-LOD resolution floats (Land Contact `2e15` … Fire Geometry `7e15`).
- LOD collections and object names are scoped under `O2L_<model>` / `<model> <LOD>`.
- Memory-point presets use space-free enum identifiers.
- Validate is model-scoped, writes the full report to a text block, and checks each ComponentXX shell.
- Mark LOD / property preset / memory point dialogs invoke; memory tools only on Memory, Hit-points, and Land Contact.
