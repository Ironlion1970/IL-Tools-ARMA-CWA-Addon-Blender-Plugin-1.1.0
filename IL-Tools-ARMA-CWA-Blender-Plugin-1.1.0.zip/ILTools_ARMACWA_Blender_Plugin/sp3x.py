"""OFP / Cold War Assault SP3X MLOD reader and writer.

Does not read ODOL or Arma 3 P3DM. Coordinates in the file are Oxygen Y-up
(X right, Y up, Z forward-ish). Callers that talk to Blender should convert.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

MLOD_MAGIC = b"MLOD"
SP3X_MAGIC = b"SP3X"
P3DM_MAGIC = b"P3DM"
ODOL_MAGIC = b"ODOL"
TAGG_MAGIC = b"TAGG"
MLOD_VERSION = 0x00000101
SP3X_MAJOR = 0x1C
SP3X_MINOR = 0x99
FACE_BYTES = 104
VERT_BYTES = 16
NORM_BYTES = 12
TEX_LEN = 32
TAG_NAME_LEN = 64

SKIP_TAGS = {"#Selected#", "#Hide#", "#Lock#", "#Animation#"}


class Sp3xError(ValueError):
    pass


def _zpad(text: str, size: int) -> bytes:
    raw = text.encode("latin1", "replace")[: size - 1]
    return raw + b"\x00" * (size - len(raw))


def _zstr(buf: bytes) -> str:
    return buf.split(b"\x00", 1)[0].decode("latin1", "replace")


@dataclass
class Vertex:
    x: float
    y: float
    z: float
    flags: int = 0


@dataclass
class Face:
    texture: str
    verts: List[int]
    normals: List[int]
    uvs: List[Tuple[float, float]]
    flags: int = 0


@dataclass
class Lod:
    resolution: float = 0.0
    flags: int = 0
    vertices: List[Vertex] = field(default_factory=list)
    normals: List[Tuple[float, float, float]] = field(default_factory=list)
    faces: List[Face] = field(default_factory=list)
    # name -> (vert_weights[nverts], face_weights[nfaces]) values 0-255
    selections: Dict[str, Tuple[List[int], List[int]]] = field(default_factory=dict)
    properties: List[Tuple[str, str]] = field(default_factory=list)
    masses: Optional[List[float]] = None
    sharp_edges: List[Tuple[int, int]] = field(default_factory=list)

    def textures(self) -> List[str]:
        seen = []
        for face in self.faces:
            if face.texture and face.texture not in seen:
                seen.append(face.texture)
        return seen

    def replace_texture_prefix(self, old: str, new: str) -> int:
        old = old.replace("/", "\\")
        new = new.replace("/", "\\")
        n = 0
        for face in self.faces:
            if face.texture.startswith(old):
                face.texture = new + face.texture[len(old) :]
                n += 1
            elif old.lower() in ("*", ""):
                continue
        return n


@dataclass
class Model:
    lods: List[Lod] = field(default_factory=list)
    source: str = ""

    def replace_texture_prefix(self, old: str, new: str) -> int:
        return sum(lod.replace_texture_prefix(old, new) for lod in self.lods)

    def all_textures(self) -> List[str]:
        seen = []
        for lod in self.lods:
            for t in lod.textures():
                if t not in seen:
                    seen.append(t)
        return seen


def _decode_selection(blob: bytes, nverts: int, nfaces: int) -> Tuple[List[int], List[int]]:
    bit_len = (nverts + 7) // 8 + (nfaces + 7) // 8
    if len(blob) == nverts + nfaces:
        return list(blob[:nverts]), list(blob[nverts : nverts + nfaces])
    if len(blob) == nverts:
        return list(blob[:nverts]), [0] * nfaces
    if len(blob) == bit_len:
        vw = []
        for i in range(nverts):
            vw.append(1 if blob[i // 8] & (1 << (i % 8)) else 0)
        fw = []
        base = (nverts + 7) // 8
        for i in range(nfaces):
            fw.append(1 if blob[base + i // 8] & (1 << (i % 8)) else 0)
        return vw, fw
    vw = list(blob[:nverts]) + [0] * max(0, nverts - len(blob))
    rest = blob[nverts:]
    fw = list(rest[:nfaces]) + [0] * max(0, nfaces - len(rest))
    return vw[:nverts], fw[:nfaces]


def _encode_selection(vert_w: List[int], face_w: List[int], nverts: int, nfaces: int) -> bytes:
    vw = [(vert_w[i] if i < len(vert_w) else 0) & 0xFF for i in range(nverts)]
    fw = [(face_w[i] if i < len(face_w) else 0) & 0xFF for i in range(nfaces)]
    return bytes(vw + fw)


def read_bytes(data: bytes, source: str = "") -> Model:
    if len(data) < 12:
        raise Sp3xError("File too small to be MLOD")
    magic = data[:4]
    if magic == ODOL_MAGIC:
        raise Sp3xError("ODOL (binarized) — convert to MLOD with odol2mlod first")
    if magic != MLOD_MAGIC:
        raise Sp3xError(f"Not MLOD (header {magic!r})")
    version, lod_count = struct.unpack_from("<II", data, 4)
    off = 12
    model = Model(source=source)
    for li in range(lod_count):
        if off + 28 > len(data):
            raise Sp3xError(f"LOD {li} header truncated")
        sig = data[off : off + 4]
        if sig == P3DM_MAGIC:
            raise Sp3xError("P3DM (Arma 3 MLOD) — this reader is OFP SP3X only")
        if sig != SP3X_MAGIC:
            raise Sp3xError(f"LOD {li} is {sig!r}, expected SP3X")
        _maj, _min, nv, nn, nf, flags = struct.unpack_from("<6I", data, off + 4)
        off += 28
        lod = Lod(flags=flags)
        for _ in range(nv):
            x, y, z, fl = struct.unpack_from("<3fI", data, off)
            lod.vertices.append(Vertex(x, y, z, fl))
            off += VERT_BYTES
        for _ in range(nn):
            lod.normals.append(struct.unpack_from("<3f", data, off))
            off += NORM_BYTES
        for _ in range(nf):
            tex = _zstr(data[off : off + TEX_LEN])
            nidx = struct.unpack_from("<I", data, off + 32)[0]
            corners = []
            for c in range(4):
                vi, ni, u, v = struct.unpack_from("<2I2f", data, off + 36 + c * 16)
                corners.append((vi, ni, u, v))
            fflags = struct.unpack_from("<I", data, off + 100)[0]
            nidx = 3 if nidx not in (3, 4) else nidx
            lod.faces.append(
                Face(
                    texture=tex,
                    verts=[corners[c][0] for c in range(nidx)],
                    normals=[corners[c][1] for c in range(nidx)],
                    uvs=[(corners[c][2], corners[c][3]) for c in range(nidx)],
                    flags=fflags,
                )
            )
            off += FACE_BYTES
        if data[off : off + 4] != TAGG_MAGIC:
            raise Sp3xError(f"LOD {li} missing TAGG at {off}")
        off += 4
        while off + 68 <= len(data):
            name = _zstr(data[off : off + TAG_NAME_LEN])
            size = struct.unpack_from("<I", data, off + 64)[0]
            off += 68
            blob = data[off : off + size]
            off += size
            if name == "#EndOfFile#":
                break
            if name in SKIP_TAGS:
                continue
            if name == "#Property#":
                for p in range(0, len(blob) // 128 * 128, 128):
                    key = _zstr(blob[p : p + 64])
                    val = _zstr(blob[p + 64 : p + 128])
                    if key:
                        lod.properties.append((key, val))
            elif name == "#Mass#":
                n = len(blob) // 4
                lod.masses = list(struct.unpack("<%df" % n, blob[: n * 4]))
            elif name == "#SharpEdges#":
                for p in range(0, len(blob) // 8 * 8, 8):
                    a, b = struct.unpack_from("<2I", blob, p)
                    lod.sharp_edges.append((a, b))
            elif name:
                lod.selections[name] = _decode_selection(blob, nv, nf)
        if off + 4 > len(data):
            raise Sp3xError(f"LOD {li} missing resolution")
        lod.resolution = struct.unpack_from("<f", data, off)[0]
        off += 4
        model.lods.append(lod)
    return model


def read_path(path: str) -> Model:
    with open(path, "rb") as fh:
        return read_bytes(fh.read(), source=path)


def _write_tag(chunks: List[bytes], name: str, blob: bytes) -> None:
    chunks.append(_zpad(name, TAG_NAME_LEN))
    chunks.append(struct.pack("<I", len(blob)))
    chunks.append(blob)


def write_bytes(model: Model) -> bytes:
    chunks: List[bytes] = [MLOD_MAGIC, struct.pack("<II", MLOD_VERSION, len(model.lods))]
    for lod in model.lods:
        nv = len(lod.vertices)
        # Rebuild a usable normal table; keep existing if present.
        normals = list(lod.normals) if lod.normals else [(0.0, 1.0, 0.0)]
        nn = len(normals)
        nf = len(lod.faces)
        chunks.append(SP3X_MAGIC)
        chunks.append(struct.pack("<6I", SP3X_MAJOR, SP3X_MINOR, nv, nn, nf, lod.flags))
        for v in lod.vertices:
            chunks.append(struct.pack("<3fI", v.x, v.y, v.z, v.flags & 0xFFFFFFFF))
        for nrm in normals:
            chunks.append(struct.pack("<3f", nrm[0], nrm[1], nrm[2]))
        for face in lod.faces:
            nidx = len(face.verts)
            if nidx not in (3, 4):
                raise Sp3xError(f"Face must have 3 or 4 verts, got {nidx}")
            tex = face.texture.replace("/", "\\")
            if len(tex.encode("latin1", "replace")) > TEX_LEN - 1:
                tex = tex.encode("latin1", "replace")[: TEX_LEN - 1].decode("latin1", "replace")
            chunks.append(_zpad(tex, TEX_LEN))
            chunks.append(struct.pack("<I", nidx))
            for c in range(4):
                if c < nidx:
                    vi = face.verts[c]
                    ni = face.normals[c] if c < len(face.normals) else 0
                    uv = face.uvs[c] if c < len(face.uvs) else (0.0, 0.0)
                else:
                    vi = face.verts[0]
                    ni = face.normals[0] if face.normals else 0
                    uv = (0.0, 0.0)
                chunks.append(struct.pack("<2I2f", vi, ni, uv[0], uv[1]))
            chunks.append(struct.pack("<I", face.flags & 0xFFFFFFFF))
        chunks.append(TAGG_MAGIC)
        sharp = b"".join(struct.pack("<2I", a, b) for a, b in lod.sharp_edges)
        _write_tag(chunks, "#SharpEdges#", sharp)
        for name, (vw, fw) in lod.selections.items():
            _write_tag(chunks, name, _encode_selection(vw, fw, nv, nf))
        if lod.properties:
            blob = b"".join(_zpad(k, 64) + _zpad(v, 64) for k, v in lod.properties)
            _write_tag(chunks, "#Property#", blob)
        if lod.masses:
            masses = list(lod.masses[:nv]) + [0.0] * max(0, nv - len(lod.masses))
            _write_tag(chunks, "#Mass#", struct.pack("<%df" % nv, *masses))
        _write_tag(chunks, "#EndOfFile#", b"")
        chunks.append(struct.pack("<f", float(lod.resolution)))
    return b"".join(chunks)


def write_path(path: str, model: Model) -> None:
    with open(path, "wb") as fh:
        fh.write(write_bytes(model))
