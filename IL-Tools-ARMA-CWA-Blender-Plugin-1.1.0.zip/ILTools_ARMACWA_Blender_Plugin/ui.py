import bpy
from bpy.types import Panel, UIList

from .lod_types import LOD_BY_ID, MEMORY_PRESETS, POINT_LOD_KINDS


class O2L_UL_properties(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "name", text="", emboss=False)
        row.prop(item, "value", text="")


class O2L_PT_main(Panel):
    bl_label = "Objektiv2"
    bl_idname = "O2L_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Objektiv2"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene.o2l, "model_name")
        layout.label(text="Name only — does not load a mesh.")
        layout.prop(scene.o2l, "texture_root")
        layout.operator("o2l.setup_model", icon="OUTLINER_COLLECTION")
        layout.operator("o2l.validate", icon="CHECKMARK")
        if scene.o2l.last_report:
            box = layout.box()
            for line in scene.o2l.last_report.splitlines()[:12]:
                box.label(text=line)
            layout.operator("o2l.report_to_text", icon="TEXT")


class O2L_PT_object(Panel):
    bl_label = "Active LOD"
    bl_idname = "O2L_PT_object"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Objektiv2"
    bl_parent_id = "O2L_PT_main"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        if obj is None:
            layout.label(text="No object selected")
            return

        layout.label(text=obj.name, icon="MESH_DATA" if obj.type == "MESH" else "EMPTY_AXIS")
        if obj.type != "MESH":
            layout.label(text="Select a mesh to mark as a LOD")
            return

        o2l = obj.o2l
        layout.prop(o2l, "is_lod")
        if not o2l.is_lod:
            layout.operator("o2l.mark_lod", icon="SOLO_ON")
            return

        layout.prop(o2l, "lod_kind")
        if o2l.lod_kind == "res":
            layout.prop(o2l, "resolution")
        else:
            kind = LOD_BY_ID.get(o2l.lod_kind)
            layout.label(text=f"Resolution {o2l.resolution:g}")
            if kind:
                layout.label(text=kind.notes)

        layout.separator()
        layout.label(text="Named selections (vertex groups)")
        row = layout.row(align=True)
        row.operator("o2l.selection_to_named", icon="GROUP_VERTEX")
        row.operator("o2l.add_component", text="ComponentXX")

        if obj.vertex_groups:
            box = layout.box()
            for vg in obj.vertex_groups:
                box.label(text=vg.name, icon="GROUP_VERTEX")


class O2L_PT_memory(Panel):
    bl_label = "Memory points"
    bl_idname = "O2L_PT_memory"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Objektiv2"
    bl_parent_id = "O2L_PT_main"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (
            obj is not None
            and obj.type == "MESH"
            and obj.o2l.is_lod
            and obj.o2l.lod_kind in POINT_LOD_KINDS
        )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Places a vertex at the 3D cursor")
        layout.operator("o2l.add_memory_point", icon="EMPTY_AXIS")
        box = layout.box()
        for _enum_id, name, hint in MEMORY_PRESETS[:8]:
            box.label(text=f"{name}  —  {hint}")


class O2L_PT_properties(Panel):
    bl_label = "Named properties"
    bl_idname = "O2L_PT_properties"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Objektiv2"
    bl_parent_id = "O2L_PT_main"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.o2l.is_lod

    def draw(self, context):
        layout = self.layout
        obj = context.object
        row = layout.row()
        row.template_list(
            "O2L_UL_properties",
            "",
            obj.o2l,
            "properties",
            obj.o2l,
            "properties_index",
            rows=3,
        )
        col = row.column(align=True)
        col.operator("o2l.add_property", icon="ADD", text="")
        col.operator("o2l.remove_property", icon="REMOVE", text="")
        layout.operator("o2l.add_property_preset", text="Add preset")


class O2L_PT_textures(Panel):
    bl_label = "Textures"
    bl_idname = "O2L_PT_textures"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Objektiv2"
    bl_parent_id = "O2L_PT_main"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        layout.label(text="OFP reads material names as texture paths.")
        layout.operator("o2l.apply_texture_path", icon="TEXTURE")
        layout.operator("o2l.remap_textures", icon="FILE_REFRESH")
        layout.operator("o2l.remap_p3d_file", icon="FILE_FOLDER")
        if obj and obj.active_material:
            layout.label(text=obj.active_material.name)
        layout.separator()
        layout.label(text="File → Import/Export → OFP MLOD (.p3d)")
        layout.label(text="Convert PNG/TGA/GIF → PAA/PAC with")
        layout.label(text="ImageToPAA, Pal2PacE, or paa-cli.")


class O2L_PT_help(Panel):
    bl_label = "How this maps to Objektiv2"
    bl_idname = "O2L_PT_help"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Objektiv2"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        col = self.layout.column()
        col.label(text="Objektiv2 Light concept → Blender")
        col.label(text="LOD window          → collections + LOD flag")
        col.label(text="Named selections    → vertex groups")
        col.label(text="Memory points       → loose verts + groups")
        col.label(text="Named properties    → panel below Active LOD")
        col.label(text="Component01…        → required on Geometry")
        col.label(text="Mass (Alt-M)        → set before P3D export")
        col.separator()
        col.label(text="Export MLOD P3D with Arma 3 Object")
        col.label(text="Builder or ArmAToolbox. This addon")
        col.label(text="prepares the scene the way O2 Light did.")


CLASSES = (
    O2L_UL_properties,
    O2L_PT_main,
    O2L_PT_object,
    O2L_PT_memory,
    O2L_PT_properties,
    O2L_PT_textures,
    O2L_PT_help,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
