import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

from .lod_types import LOD_ENUM, LOD_BY_ID


def _lod_kind_update(self, context):
    kind = LOD_BY_ID.get(self.lod_kind)
    if kind and kind.id != "res":
        self.resolution = kind.resolution


class O2LNamedProperty(PropertyGroup):
    name: StringProperty(name="Key", default="forcenotalpha")
    value: StringProperty(name="Value", default="1")


class O2LObjectProps(PropertyGroup):
    is_lod: BoolProperty(
        name="Objektiv2 LOD",
        description="Treat this object as one P3D LOD (Objektiv2 / Oxygen style)",
        default=False,
    )
    lod_kind: EnumProperty(
        name="LOD type",
        items=LOD_ENUM,
        default="res",
        update=_lod_kind_update,
    )
    resolution: FloatProperty(
        name="Resolution",
        description="Graphical LOD resolution, or the special-LOD sentinel float",
        default=0.0,
        min=0.0,
    )
    properties: CollectionProperty(type=O2LNamedProperty)
    properties_index: IntProperty(default=0)


class O2LSceneProps(PropertyGroup):
    model_name: StringProperty(
        name="Model name",
        description="Name for collections and objects only (O2L_hummer, hummer Resolution 0). Does not load a vehicle mesh.",
        default="newmodel",
    )
    texture_root: StringProperty(
        name="Texture root",
        description="Prefix written onto materials, e.g. data\\ or myaddon\\data\\",
        default="data\\",
    )
    last_report: StringProperty(
        name="Last report",
        default="",
        maxlen=8192,
        description="Short preview. Full validate output is the 'Objektiv2 Report' text block.",
    )


class O2LAddonPrefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    project_root: StringProperty(
        name="Project root (P:)",
        description="Virtual drive used by Oxygen / TexView / ImageToPAA",
        subtype="DIR_PATH",
        default="",
    )
    paa_tool: StringProperty(
        name="Texture tool",
        description="Optional path to Pal2PacE, ImageToPAA, or paa-cli",
        subtype="FILE_PATH",
        default="",
    )

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "project_root")
        col.prop(self, "paa_tool")
        col.label(text="P3D import/export: install Arma 3 Object Builder or ArmAToolbox.")


CLASSES = (
    O2LNamedProperty,
    O2LObjectProps,
    O2LSceneProps,
    O2LAddonPrefs,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.o2l = PointerProperty(type=O2LObjectProps)
    bpy.types.Scene.o2l = PointerProperty(type=O2LSceneProps)


def unregister():
    del bpy.types.Object.o2l
    del bpy.types.Scene.o2l
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
