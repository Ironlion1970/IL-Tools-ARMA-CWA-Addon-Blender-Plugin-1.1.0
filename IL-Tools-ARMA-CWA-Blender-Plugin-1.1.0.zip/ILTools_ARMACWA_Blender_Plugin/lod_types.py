"""OFP / Objektiv2 Light LOD kinds and their resolution floats.

Resolution sentinels match MLOD / Oxygen / Object Builder / Real Virtuality
as documented on the BI wiki (P3D Model Info, LOD) and the PMC OFP MLOD
appendix. Graphical LODs use any resolution < 1000.
"""

from collections import namedtuple

LodKind = namedtuple("LodKind", "id label resolution ofp notes")

# ofp=True means this LOD existed in Objektiv2 Light / OFP.
# Functional-LOD floats after Memory are 2e15, 3e15, … 7e15 — not the e16 ladder.
LOD_KINDS = (
    LodKind("res", "Resolution", 0.0, True, "Visible mesh. Use 0, 1, 2, 3… or 0.5 / 1.5 / 3 / 5 / 7."),
    LodKind("view_gunner", "View Gunner", 1.0e3, True, "1st-person gunner mesh."),
    LodKind("view_pilot", "View Pilot", 1.1e3, True, "1st-person driver / pilot mesh."),
    LodKind("view_cargo", "View Cargo", 1.2e3, True, "1st-person passenger mesh."),
    LodKind("shadow", "Shadow Volume", 1.0e4, True, "Stencil / volume shadow. Keep it simple and closed."),
    LodKind("geometry", "Geometry", 1.0e13, True, "Collision. Closed convex Component01… components + vertex mass."),
    LodKind("memory", "Memory", 1.0e15, True, "Points only: lights, anim axes, muzzle, entry, proxies."),
    LodKind("landcontact", "Land Contact", 2.0e15, True, "Ground contact vertices (wheels, feet)."),
    LodKind("roadway", "Roadway", 3.0e15, True, "Walkable surface (bridges, decks)."),
    LodKind("paths", "Paths", 4.0e15, True, "AI path network for soldiers on the object."),
    LodKind("hitpoints", "Hit-points", 5.0e15, True, "Unconnected verts named for damage (kol, motor, svetlo…)."),
    LodKind("view_geom", "View Geometry", 6.0e15, True, "Occlusion / line-of-sight. Closed convex components."),
    LodKind("fire_geom", "Fire Geometry", 7.0e15, True, "Bullet penetration proxy. Closed components."),
)

LOD_BY_ID = {k.id: k for k in LOD_KINDS}


def kind_from_resolution(res):
    """Map a P3D resolution float to a lod_kind id."""
    if res < 999.5:
        return "res"
    best_id = "res"
    best_err = None
    for kind in LOD_KINDS:
        if kind.id == "res":
            continue
        err = abs(float(res) - kind.resolution)
        rel = err / max(kind.resolution, 1.0)
        if best_err is None or rel < best_err:
            best_err = rel
            best_id = kind.id
    return best_id if best_err is not None and best_err < 0.25 else "res"

LOD_ENUM = [(k.id, k.label, k.notes) for k in LOD_KINDS]

# Point-style LODs: loose vertices + a named selection each.
POINT_LOD_KINDS = frozenset({"memory", "hitpoints", "landcontact"})

# Common graphical resolution steps used on BI OFP vehicles.
RES_PRESETS = (0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 9.0)

# Memory-point names that OFP configs and model.cfg actually look for.
# Tuple is (enum_id, vertex_group_name, hint). enum_id must be a valid RNA identifier.
MEMORY_PRESETS = (
    ("zasleh", "zasleh", "Muzzle flash origin"),
    ("konec_hlavne", "konec hlavne", "Muzzle / barrel end"),
    ("usti_hlavne", "usti hlavne", "Barrel start (inside)"),
    ("otochlaven", "otochlaven", "Turret / gun rotate axis"),
    ("osaveze", "osaveze", "Turret yaw axis"),
    ("osa_vlku", "osa_vlku", "Wheel rotate axis (example)"),
    ("pos_driver", "pos driver", "Driver get-in / position"),
    ("pos_gunner", "pos gunner", "Gunner get-in / position"),
    ("pos_cargo", "pos cargo", "Cargo get-in / position"),
    ("doplnovani", "doplnovani", "Refuel / rearm point"),
    ("stopa", "stopa", "Ground dust / track origin"),
    ("l_svetlo", "l svetlo", "Left light"),
    ("p_svetlo", "p svetlo", "Right light"),
    ("zadni_svetlo", "zadni svetlo", "Rear light"),
)

MEMORY_BY_ID = {p[0]: p for p in MEMORY_PRESETS}

MEMORY_ENUM = [(p[0], p[1], p[2]) for p in MEMORY_PRESETS] + [
    ("custom", "Custom", "Use the Name field"),
]

# Geometry named selections Objektiv2 expected.
COMPONENT_HINT = "Component{:02d}"

NAMED_PROPERTY_PRESETS = (
    ("forcenotalpha", "1"),
    ("lodnoshadow", "1"),
    ("animated", "1"),
    ("autocenter", "0"),
    ("map", "house"),
    ("class", "house"),
    ("prefershadowvolume", "1"),
)
