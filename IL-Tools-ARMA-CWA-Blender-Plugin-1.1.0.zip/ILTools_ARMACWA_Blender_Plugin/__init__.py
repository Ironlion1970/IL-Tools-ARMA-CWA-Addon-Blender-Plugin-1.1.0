bl_info = {
    "name": "ILTools ARMA CWA Blender Plugin",
    "author": "ILTools",
    "version": (1, 1, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Objektiv2",
    "description": "Arma: Cold War Assault / OFP LOD, named-selection, memory-point and SP3X P3D workflow",
    "doc_url": "https://community.bistudio.com/wiki/P3D_File_Format_-_MLOD",
    "category": "3D View",
}

from . import io_p3d, operators, props, ui


def register():
    props.register()
    operators.register()
    io_p3d.register()
    ui.register()


def unregister():
    ui.unregister()
    io_p3d.unregister()
    operators.unregister()
    props.unregister()


if __name__ == "__main__":
    register()
