import bmesh
import bpy
from bpy.props import EnumProperty, FloatProperty, StringProperty

from .lod_types import (
    COMPONENT_HINT,
    LOD_BY_ID,
    LOD_ENUM,
    MEMORY_BY_ID,
    MEMORY_ENUM,
    NAMED_PROPERTY_PRESETS,
    POINT_LOD_KINDS,
    RES_PRESETS,
)


def _ensure_collection(name, parent=None):
    """Create or reuse a collection. Child lookups are scoped to *parent* so a
    second model does not steal the first model's Geometry/Memory collections.
    """
    if parent is not None:
        existing = parent.children.get(name)
        if existing is not None:
            return existing
        col = bpy.data.collections.new(name)
        parent.children.link(col)
        return col

    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    elif col.name not in bpy.context.scene.collection.children:
        try:
            bpy.context.scene.collection.children.link(col)
        except RuntimeError:
            pass
    return col


def _link_object(obj, collection):
    for col in list(obj.users_collection):
        col.objects.unlink(obj)
    collection.objects.link(obj)


def _new_empty_mesh(name):
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    return obj


def _fill_box(obj, size=(2.2, 4.6, 1.8)):
    """Axis-aligned box centered on origin. Size is (X width, Y length, Z height) metres."""
    sx, sy, sz = (0.5 * abs(c) for c in size)
    verts = (
        (-sx, -sy, 0.0),
        (sx, -sy, 0.0),
        (sx, sy, 0.0),
        (-sx, sy, 0.0),
        (-sx, -sy, sz * 2),
        (sx, -sy, sz * 2),
        (sx, sy, sz * 2),
        (-sx, sy, sz * 2),
    )
    faces = (
        (0, 1, 2, 3),
        (4, 7, 6, 5),
        (0, 4, 5, 1),
        (1, 5, 6, 2),
        (2, 6, 7, 3),
        (3, 7, 4, 0),
    )
    obj.data.from_pydata(verts, [], faces)
    obj.data.update()


def _hide_startup_cube(context):
    """The default cube is easy to mistake for the new model."""
    cube = bpy.data.objects.get("Cube")
    if cube is None or cube.type != "MESH":
        return
    if getattr(cube, "o2l", None) and cube.o2l.is_lod:
        return
    if len(cube.data.vertices) != 8:
        return
    cube.select_set(False)
    cube.hide_set(True)
    cube.hide_viewport = True


def _add_vertex_group(obj, name, indices, weight=1.0):
    vg = obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
    if indices:
        vg.add(list(indices), weight, "REPLACE")
    return vg


def _iter_collection_objects(col):
    yield from col.objects
    for child in col.children:
        yield from _iter_collection_objects(child)


def _model_root_name(scene):
    return f"O2L_{scene.o2l.model_name or 'model'}"


def _lods_for_validate(context):
    """Prefer the current model's O2L_* collection; else selected LODs; else scene."""
    scene = context.scene
    root_name = _model_root_name(scene)
    root = bpy.data.collections.get(root_name)
    if root is not None:
        lods = [
            o for o in _iter_collection_objects(root)
            if getattr(o, "o2l", None) and o.o2l.is_lod and o.type == "MESH"
        ]
        if lods:
            return lods, root_name

    selected = [
        o for o in context.selected_objects
        if getattr(o, "o2l", None) and o.o2l.is_lod and o.type == "MESH"
    ]
    if selected:
        return selected, "selection"

    lods = [
        o for o in scene.objects
        if getattr(o, "o2l", None) and o.o2l.is_lod and o.type == "MESH"
    ]
    return lods, "scene"


def _write_report(context, report):
    text = bpy.data.texts.get("Objektiv2 Report") or bpy.data.texts.new("Objektiv2 Report")
    text.clear()
    text.write(report)
    # Scene property is a short preview; full text lives in the text block.
    preview_lines = report.splitlines()
    preview = "\n".join(preview_lines[:24])
    if len(preview_lines) > 24:
        preview += "\n…"
    context.scene.o2l.last_report = preview
    return text


def _vg_vert_indices(obj, vg):
    idx = vg.index
    return [v.index for v in obj.data.vertices if any(g.group == idx for g in v.groups)]


def _submesh_closed(obj, vert_indices):
    """Whether faces that live entirely inside vert_indices form a closed shell."""
    vset = set(vert_indices)
    if len(vset) < 4:
        return False
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    try:
        bm.verts.ensure_lookup_table()
        faces = [f for f in bm.faces if all(v.index in vset for v in f.verts)]
        if not faces:
            return False
        for e in bm.edges:
            n = sum(1 for f in e.link_faces if all(v.index in vset for v in f.verts))
            if n not in (0, 2):
                return False
        return True
    finally:
        bm.free()


class O2L_OT_setup_model(bpy.types.Operator):
    bl_idname = "o2l.setup_model"
    bl_label = "Create Objektiv2 model"
    bl_description = "Create the standard OFP LOD collection set used in Objektiv2 Light"
    bl_options = {"REGISTER", "UNDO"}

    include_views: bpy.props.BoolProperty(name="View Pilot/Cargo/Gunner", default=True)
    include_shadow: bpy.props.BoolProperty(name="Shadow LOD", default=True)
    include_fire_view: bpy.props.BoolProperty(name="Fire + View Geometry", default=True)
    res_count: bpy.props.IntProperty(name="Resolution LODs", default=3, min=1, max=8)
    starter_box: bpy.props.BoolProperty(
        name="Starter box on Resolution 0",
        description="Add a placeholder volume so the viewport is not just the default Cube. Replace it with your mesh.",
        default=True,
    )

    def execute(self, context):
        scene = context.scene
        model = scene.o2l.model_name or "model"
        root_name = _model_root_name(scene)
        existing = bpy.data.collections.get(root_name)
        if existing is not None and (len(existing.objects) or len(existing.children)):
            self.report(
                {"ERROR"},
                f"'{root_name}' already exists — rename Model or delete that collection",
            )
            return {"CANCELLED"}

        root = _ensure_collection(root_name)

        created = []

        def add_lod(kind_id, res, suffix=""):
            kind = LOD_BY_ID[kind_id]
            name = f"{model} {kind.label}{suffix}"
            obj = _new_empty_mesh(name)
            obj.o2l.is_lod = True
            obj.o2l.lod_kind = kind_id
            obj.o2l.resolution = res
            col = _ensure_collection(name, root)
            _link_object(obj, col)
            created.append(obj)
            return obj

        for i in range(self.res_count):
            res = RES_PRESETS[i] if i < len(RES_PRESETS) else float(i)
            add_lod("res", res, suffix=f" {res:g}")

        add_lod("geometry", LOD_BY_ID["geometry"].resolution)
        add_lod("memory", LOD_BY_ID["memory"].resolution)
        add_lod("landcontact", LOD_BY_ID["landcontact"].resolution)
        add_lod("hitpoints", LOD_BY_ID["hitpoints"].resolution)

        if self.include_views:
            add_lod("view_pilot", LOD_BY_ID["view_pilot"].resolution)
            add_lod("view_gunner", LOD_BY_ID["view_gunner"].resolution)
            add_lod("view_cargo", LOD_BY_ID["view_cargo"].resolution)
        if self.include_shadow:
            add_lod("shadow", LOD_BY_ID["shadow"].resolution)
        if self.include_fire_view:
            add_lod("view_geom", LOD_BY_ID["view_geom"].resolution)
            add_lod("fire_geom", LOD_BY_ID["fire_geom"].resolution)

        geo = next(o for o in created if o.o2l.lod_kind == "geometry")
        _add_vertex_group(geo, "Component01", [])

        res0 = next(o for o in created if o.o2l.lod_kind == "res")
        if self.starter_box:
            _fill_box(res0)
            _fill_box(geo)
            _add_vertex_group(geo, "Component01", list(range(len(geo.data.vertices))))

        _hide_startup_cube(context)
        for obj in list(context.selected_objects):
            obj.select_set(False)
        context.view_layer.objects.active = res0
        res0.select_set(True)
        self.report(
            {"INFO"},
            f"Created {len(created)} LODs under {root_name}. "
            f"'{res0.name}' is a placeholder — model or import the real mesh there.",
        )
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_mark_lod(bpy.types.Operator):
    bl_idname = "o2l.mark_lod"
    bl_label = "Mark as Objektiv2 LOD"
    bl_options = {"REGISTER", "UNDO"}

    lod_kind: EnumProperty(name="LOD type", items=LOD_ENUM, default="res")
    resolution: FloatProperty(name="Resolution", default=0.0, min=0.0)

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select a mesh")
            return {"CANCELLED"}
        kind = LOD_BY_ID[self.lod_kind]
        obj.o2l.is_lod = True
        obj.o2l.lod_kind = self.lod_kind
        obj.o2l.resolution = self.resolution if kind.id == "res" else kind.resolution
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_selection_to_named(bpy.types.Operator):
    bl_idname = "o2l.selection_to_named"
    bl_label = "Selection → named selection"
    bl_description = "Create or replace a vertex group from the current vertex selection"
    bl_options = {"REGISTER", "UNDO"}

    sel_name: StringProperty(name="Name", default="Component01")

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select a mesh")
            return {"CANCELLED"}
        if obj.mode != "EDIT":
            self.report({"ERROR"}, "Switch to Edit Mode and select vertices")
            return {"CANCELLED"}
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        indices = [v.index for v in bm.verts if v.select]
        if not indices:
            self.report({"ERROR"}, "No vertices selected")
            return {"CANCELLED"}
        bpy.ops.object.mode_set(mode="OBJECT")
        _add_vertex_group(obj, self.sel_name, indices)
        bpy.ops.object.mode_set(mode="EDIT")
        self.report({"INFO"}, f"{self.sel_name}: {len(indices)} verts")
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_add_component(bpy.types.Operator):
    bl_idname = "o2l.add_component"
    bl_label = "Add next ComponentXX"
    bl_description = "Create the next Component01–99 named selection from the current vertex selection"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select a mesh")
            return {"CANCELLED"}
        used = set()
        for vg in obj.vertex_groups:
            if vg.name.lower().startswith("component") and vg.name[9:].isdigit():
                used.add(int(vg.name[9:]))
        n = 1
        while n in used and n < 99:
            n += 1
        name = COMPONENT_HINT.format(n)
        if obj.mode == "EDIT":
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            indices = [v.index for v in bm.verts if v.select]
            if not indices:
                self.report({"WARNING"}, f"{name} created empty — select vertices first")
            bpy.ops.object.mode_set(mode="OBJECT")
            _add_vertex_group(obj, name, indices)
            bpy.ops.object.mode_set(mode="EDIT")
        else:
            _add_vertex_group(obj, name, [])
            self.report({"WARNING"}, f"{name} created empty — switch to Edit Mode and select vertices")
            return {"FINISHED"}
        self.report({"INFO"}, name)
        return {"FINISHED"}


class O2L_OT_add_memory_point(bpy.types.Operator):
    bl_idname = "o2l.add_memory_point"
    bl_label = "Add memory point"
    bl_description = "Add a single vertex (and vertex group) on the Memory LOD"
    bl_options = {"REGISTER", "UNDO"}

    point_name: StringProperty(name="Name", default="zasleh")
    preset: EnumProperty(
        name="Preset",
        items=MEMORY_ENUM,
        default="zasleh",
    )

    def execute(self, context):
        if self.preset == "custom":
            name = self.point_name.strip() or "point"
        else:
            name = MEMORY_BY_ID[self.preset][1]
        obj = context.object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select the Memory LOD mesh")
            return {"CANCELLED"}
        if obj.o2l.is_lod and obj.o2l.lod_kind not in POINT_LOD_KINDS:
            self.report(
                {"ERROR"},
                f"{obj.name} is a {LOD_BY_ID[obj.o2l.lod_kind].label} LOD — pick Memory, Hit-points, or Land Contact",
            )
            return {"CANCELLED"}

        cursor = context.scene.cursor.location
        local = obj.matrix_world.inverted() @ cursor

        was_edit = obj.mode == "EDIT"
        if was_edit:
            bpy.ops.object.mode_set(mode="OBJECT")

        existing = obj.vertex_groups.get(name)
        already = existing is not None and any(
            g.group == existing.index for v in obj.data.vertices for g in v.groups
        )

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.new(local)
        bm.verts.ensure_lookup_table()
        idx = len(bm.verts) - 1
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        _add_vertex_group(obj, name, [idx])

        if was_edit:
            bpy.ops.object.mode_set(mode="EDIT")
        if already:
            self.report({"WARNING"}, f"'{name}' already existed — added another vertex to that selection")
        else:
            self.report({"INFO"}, f"Point '{name}' at cursor")
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_add_property(bpy.types.Operator):
    bl_idname = "o2l.add_property"
    bl_label = "Add named property"
    bl_options = {"REGISTER", "UNDO"}

    key: StringProperty(name="Key", default="forcenotalpha")
    value: StringProperty(name="Value", default="1")

    def execute(self, context):
        obj = context.object
        if obj is None:
            return {"CANCELLED"}
        item = obj.o2l.properties.add()
        item.name = self.key
        item.value = self.value
        obj.o2l.properties_index = len(obj.o2l.properties) - 1
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_add_property_preset(bpy.types.Operator):
    bl_idname = "o2l.add_property_preset"
    bl_label = "Add property preset"
    bl_options = {"REGISTER", "UNDO"}

    preset: EnumProperty(
        name="Preset",
        items=[(k, f"{k} = {v}", "") for k, v in NAMED_PROPERTY_PRESETS],
    )

    def execute(self, context):
        obj = context.object
        if obj is None:
            return {"CANCELLED"}
        key, value = self.preset, dict(NAMED_PROPERTY_PRESETS)[self.preset]
        item = obj.o2l.properties.add()
        item.name = key
        item.value = value
        obj.o2l.properties_index = len(obj.o2l.properties) - 1
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class O2L_OT_remove_property(bpy.types.Operator):
    bl_idname = "o2l.remove_property"
    bl_label = "Remove named property"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.object
        if obj is None:
            return {"CANCELLED"}
        idx = obj.o2l.properties_index
        if 0 <= idx < len(obj.o2l.properties):
            obj.o2l.properties.remove(idx)
            obj.o2l.properties_index = max(0, idx - 1)
        return {"FINISHED"}


class O2L_OT_apply_texture_path(bpy.types.Operator):
    bl_idname = "o2l.apply_texture_path"
    bl_label = "Stamp OFP texture path"
    bl_description = "Set the active material name to an OFP-style data\\\\name.paa path"
    bl_options = {"REGISTER", "UNDO"}

    filename: StringProperty(name="File", default="texture.paa")

    def execute(self, context):
        obj = context.object
        if obj is None or not obj.active_material:
            self.report({"ERROR"}, "Select an object with an active material")
            return {"CANCELLED"}
        root = context.scene.o2l.texture_root.replace("/", "\\")
        if root and not root.endswith("\\"):
            root += "\\"
        name = self.filename.replace("/", "\\")
        obj.active_material.name = root + name
        self.report({"INFO"}, obj.active_material.name)
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


def _mesh_closed(obj):
    """True if every edge is shared by 2 faces (watertight)."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    try:
        if not bm.faces:
            return False
        for e in bm.edges:
            if len(e.link_faces) != 2:
                return False
        return True
    finally:
        bm.free()


def _face_count(obj):
    return len(obj.data.polygons)


def _loose_vert_count(obj):
    mesh = obj.data
    used = [False] * len(mesh.vertices)
    for p in mesh.polygons:
        for vi in p.vertices:
            used[vi] = True
    return sum(1 for u in used if not u)


class O2L_OT_validate(bpy.types.Operator):
    bl_idname = "o2l.validate"
    bl_label = "Validate Objektiv2 model"
    bl_description = "Check LOD set, ComponentXX groups, closed geometry, memory points"

    def execute(self, context):
        lines = []
        errors = 0
        warns = 0

        lods, scope = _lods_for_validate(context)
        if not lods:
            self.report({"ERROR"}, "No objects marked as Objektiv2 LODs")
            return {"CANCELLED"}

        kinds = {}
        for o in lods:
            kinds.setdefault(o.o2l.lod_kind, []).append(o)

        def err(msg):
            nonlocal errors
            errors += 1
            lines.append(f"ERROR  {msg}")

        def warn(msg):
            nonlocal warns
            warns += 1
            lines.append(f"WARN   {msg}")

        def ok(msg):
            lines.append(f"OK     {msg}")

        lines.append(f"Scope: {scope}")
        lines.append(f"LODs: {len(lods)}")
        if "res" not in kinds:
            err("No Resolution LOD")
        else:
            ok(f"Resolution LODs: {len(kinds['res'])}")

        if "geometry" not in kinds:
            err("No Geometry LOD (collision will fail)")
        else:
            for geo in kinds["geometry"]:
                comps = [vg for vg in geo.vertex_groups if vg.name.lower().startswith("component")]
                if not comps:
                    err(f"{geo.name}: Geometry needs Component01… named selections")
                else:
                    assigned = set()
                    for vg in comps:
                        idxs = _vg_vert_indices(geo, vg)
                        assigned.update(idxs)
                        if not idxs:
                            err(f"{geo.name}: {vg.name} is empty")
                        elif not _submesh_closed(geo, idxs):
                            err(f"{geo.name}: {vg.name} is not a closed shell")
                        else:
                            ok(f"{geo.name}: {vg.name} closed ({len(idxs)} verts)")
                    orphan = len(geo.data.vertices) - len(assigned)
                    if orphan > 0:
                        warn(f"{geo.name}: {orphan} vert(s) not in any ComponentXX")
                if len(geo.data.vertices) == 0:
                    err(f"{geo.name}: empty mesh")
                elif not _mesh_closed(geo):
                    err(f"{geo.name}: whole mesh not closed (every edge must have 2 faces)")
                else:
                    ok(f"{geo.name}: closed mesh")
                if _face_count(geo) > 256:
                    warn(f"{geo.name}: {_face_count(geo)} faces — keep Geometry very simple")
                warn(f"{geo.name}: no vertex mass in this add-on — exporter must write #Mass#")
                warn(f"{geo.name}: convexity per component is not checked")

        if "memory" not in kinds:
            warn("No Memory LOD (animations / lights / get-in will have nowhere to attach)")
        else:
            for mem in kinds["memory"]:
                n = len(mem.data.vertices)
                ok(f"{mem.name}: {n} points, {len(mem.vertex_groups)} named selections")
                if _face_count(mem):
                    warn(f"{mem.name}: Memory LOD should be points only, found faces")

        if "landcontact" in kinds:
            for lc in kinds["landcontact"]:
                if _face_count(lc):
                    warn(f"{lc.name}: Land Contact should be vertices, not faces")
                ok(f"{lc.name}: {len(lc.data.vertices)} contact verts")

        if "hitpoints" in kinds:
            for hp in kinds["hitpoints"]:
                if _face_count(hp):
                    warn(f"{hp.name}: Hit-points should be unconnected vertices")
                if not hp.vertex_groups:
                    warn(f"{hp.name}: no named selections (motor, kol, svetlo…)")

        if "shadow" in kinds:
            for sh in kinds["shadow"]:
                if len(sh.data.vertices) and not _mesh_closed(sh):
                    warn(f"{sh.name}: Shadow Volume should be closed")
                if _face_count(sh) > 256:
                    warn(f"{sh.name}: {_face_count(sh)} faces — keep Shadow simple")

        if "fire_geom" in kinds:
            for fg in kinds["fire_geom"]:
                if len(fg.data.vertices) and not _mesh_closed(fg):
                    warn(f"{fg.name}: Fire Geometry should be closed")

        if "view_geom" in kinds:
            for vg in kinds["view_geom"]:
                if len(vg.data.vertices) and not _mesh_closed(vg):
                    warn(f"{vg.name}: View Geometry should be closed")

        seen_res = {}
        for o in lods:
            key = (o.o2l.lod_kind, round(o.o2l.resolution, 6))
            if key in seen_res:
                warn(f"Duplicate LOD {o.o2l.lod_kind} res={o.o2l.resolution:g}: {o.name} and {seen_res[key].name}")
            seen_res[key] = o

        header = f"{errors} error(s), {warns} warning(s)"
        report = header + "\n" + "\n".join(lines)
        _write_report(context, report)
        level = {"ERROR"} if errors else ({"WARNING"} if warns else {"INFO"})
        self.report(level, header)
        print("\n=== Objektiv2 validate ===\n" + report)
        return {"FINISHED"}


class O2L_OT_report_to_text(bpy.types.Operator):
    bl_idname = "o2l.report_to_text"
    bl_label = "Copy last report to text block"

    def execute(self, context):
        text = bpy.data.texts.get("Objektiv2 Report")
        if text is None or not text.as_string():
            text = _write_report(context, context.scene.o2l.last_report or "(run Validate first)")
        self.report({"INFO"}, "Wrote text block 'Objektiv2 Report'")
        return {"FINISHED"}


CLASSES = (
    O2L_OT_setup_model,
    O2L_OT_mark_lod,
    O2L_OT_selection_to_named,
    O2L_OT_add_component,
    O2L_OT_add_memory_point,
    O2L_OT_add_property,
    O2L_OT_add_property_preset,
    O2L_OT_remove_property,
    O2L_OT_apply_texture_path,
    O2L_OT_validate,
    O2L_OT_report_to_text,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
